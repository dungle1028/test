
export default function Footer() {
    return <footer className="footer mt-4">
        <p className="col">
            Copyright <a href="https://www.JMaster.io">JMaster.io</a>
        </p>
    </footer>
}