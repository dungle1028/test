//package jmaster.io.monitoradmin;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class MonitoradminApplicationTests {
//
//    @Test
//    void contextLoads() {
//    }
//}
